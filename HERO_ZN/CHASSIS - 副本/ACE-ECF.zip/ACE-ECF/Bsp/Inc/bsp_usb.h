#ifndef __BSP_USB_H
#define __BSP_USB_H
#include "main.h"
void printf_usb(const char *format, ...);
// void Usb_RX(uint8_t *buf,uint8_t *len);



#endif

