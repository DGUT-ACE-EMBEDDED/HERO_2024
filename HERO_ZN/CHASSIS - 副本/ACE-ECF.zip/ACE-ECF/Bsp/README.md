# Bsp
 ACE Embedded Common Framework Bsp part ACE电控通用框架板间支持包部分



## 第一代更新排班

- [x] Dr16
- [x] Can
- [ ] Referee
- [x] Usb_cdc
- [x] Buzzer
- [x] Motor_Encoder
- [x] pwm

## 迭代排班

- [ ] Buzzer（函数不完整、还没支持A板）
- [ ] pwm（摩擦轮还没测试）
- [ ] Motor_Encoder(更多功能在完善)
- [x] can（收发压力百分比输出）(尽量少用usb或者串口的printf,频率太高必爆栈)

## CAN FIFO

